package com.example.unittestdemo


import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import androidx.lifecycle.Observer
import com.example.unittestdemo.other.Constants
import com.example.unittestdemo.other.Event
import com.example.unittestdemo.other.Resource
import com.example.unittestdemo.other.Status
import com.example.unittestdemo.shopping_repository.ShoppingRepository
import com.example.unittestdemo.data.local.ShoppingItem
import com.example.unittestdemo.viewmodel.ShoppingViewModel
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.junit.MockitoJUnitRunner


@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class ShoppingViewModelTest {
    lateinit var viewModel: ShoppingViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    @get:Rule
    var mainCoroutineRule = MainCoroutineRule()

    @Mock
    private lateinit var repository: ShoppingRepository

    @Mock
    private lateinit var insertShoppingItemsStatusObserver: Observer<Event<Resource<ShoppingItem>>>

    @Mock
    private lateinit var insertShoppingItemsObserver: Observer<List<ShoppingItem>>


    @Captor
    private lateinit var insertShoppingItemStatusErrorCaptor: ArgumentCaptor<Event<Resource<ShoppingItem>>>
    @Captor
    private lateinit var insertShoppingItemCaptor: ArgumentCaptor<List<ShoppingItem>>


    @Before
    fun init() {
        viewModel = ShoppingViewModel(repository)
    }

    @Test
    fun insertShoppingItemWithEmptyFieldReturnsErrorTest() {
        viewModel.insertShoppingItem("balu", "", "45")
        val result = viewModel.insertShoppingItemsStatus.getOrAwaitValueTest()
        assertThat(result.getContentIfNotHandled()?.status).isEqualTo(Status.ERROR)
    }

    @Test
    fun insertShoppingItemWithTooLongNameReturnErrorTest() {
        val name = buildString {
            (1..Constants.MAX_NAME_LENGTH + 1).forEach { _ ->
                append(1)
            }
        }
        viewModel.insertShoppingItem(name, "67", "99")
        val result = viewModel.insertShoppingItemsStatus.getOrAwaitValueTest { }
        assertThat(result.getContentIfNotHandled()?.status).isEqualTo(Status.ERROR)
    }

    @Test
    fun insertShoppingItemWithTooLongPriceReturnErrorTest() {
        val price = buildString {
            (1..Constants.MAX_PRICE_LENGTH + 1).forEach { _ ->
                append(1)
            }
        }
        viewModel.insertShoppingItem("balu", price, "99")
        val result = viewModel.insertShoppingItemsStatus.getOrAwaitValueTest { }
        assertThat(result.getContentIfNotHandled()?.status).isEqualTo(Status.ERROR)
    }

    @Test
    fun insertShoppingItemWithTooHighAmountReturnErrorTest() {
        mainCoroutineRule.runTest {
            viewModel.insertShoppingItemsStatus.observeForever(insertShoppingItemsStatusObserver)
            viewModel.insertShoppingItem("Grape", "43243243243243243299S67", "99")

            verify(insertShoppingItemsStatusObserver, times(1)).onChanged(
                insertShoppingItemStatusErrorCaptor.capture()
            )
            //val result = viewModel.insertShoppingItemsStatus.getOrAwaitValueTest { }
            assertEquals(
                "Price must be valid amount",
                insertShoppingItemStatusErrorCaptor.value.getContentIfNotHandled()?.message
            )
        }
    }

    @Test
    fun insertShoppingItemWithValidInputReturnSuccessTest() {
        viewModel.insertShoppingItem("Grape", "45", "99")
        val result = viewModel.insertShoppingItemsStatus.getOrAwaitValueTest { }
        assertThat(result.getContentIfNotHandled()?.status).isEqualTo(Status.SUCCESS)
    }
    

}