package com.example.unittestdemo
import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.unittestdemo.getOrAwaitValueTest
import com.example.unittestdemo.service.ApiService
import com.example.unittestdemo.viewmodel.MainViewModel
import com.google.common.truth.Truth.assertThat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.setMain
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations

@ExperimentalCoroutinesApi
@RunWith(JUnit4::class)
class MainViewModelTest {

    private lateinit var viewModel: MainViewModel

    @get:Rule
    var instantTaskExecutorRule = InstantTaskExecutorRule()

    var testDispatcher = StandardTestDispatcher()

    @Mock
    lateinit var apiService: ApiService


    @Before
    fun init() {
        MockitoAnnotations.initMocks(this)
        Dispatchers.setMain(testDispatcher)
        viewModel = MainViewModel(apiService)
    }

    @Test
    fun testGetUsers(){
        runBlocking {
            Mockito.`when`(apiService.getApiUsers()).thenReturn(listOf("ABC","BK","XYZ"))
            viewModel.getUsers()
            assertThat(viewModel.liveDataList.getOrAwaitValueTest()?.size).isEqualTo(3)
        }
    }

    @Test
    fun testAddUser(){

    }
}