package com.example.unittestdemo

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.unittestdemo.viewmodel.SampleViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestCoroutineDispatcher
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentCaptor
import org.mockito.Captor
import org.mockito.Mockito.*
import org.mockito.junit.MockitoJUnitRunner


@RunWith(MockitoJUnitRunner::class)
@ExperimentalCoroutinesApi
class SampleViewModelTest {

    private lateinit var viewModel: SampleViewModel


    @get:Rule
    val rule = MainCoroutineRule()

    @get:Rule
    val instantTaskExecutorRule = InstantTaskExecutorRule()

    val testDispatcher = TestCoroutineDispatcher()

    @Captor
    private lateinit var acLong: ArgumentCaptor<Long>

    @Before
    fun setUp(){
        viewModel = SampleViewModel(testDispatcher)
    }

    @Test
    fun saveSessionDataTest(){
        rule.runTest { viewModel.saveSessionData()
            val userData = viewModel.getUserData()
            assertEquals("some_user_data", userData)}
    }



    @Test
    fun test() {
        val mockViewModel: SampleViewModel = mock(SampleViewModel::class.java)
        `when`(mockViewModel.squareLong(2L)).thenReturn(4L)
        assertEquals(4L, mockViewModel.squareLong(2L))
        verify(mockViewModel).squareLong(acLong.capture())
        assertEquals(2, acLong.value)
    }
}