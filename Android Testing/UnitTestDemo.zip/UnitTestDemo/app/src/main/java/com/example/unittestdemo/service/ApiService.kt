package com.example.unittestdemo.service

import com.example.unittestdemo.model.User

interface ApiService {

    fun getApiUsers() : List<String>

    fun addUser(user: User)
}