package com.example.unittestdemo.shopping_repository

import androidx.lifecycle.LiveData
import com.example.unittestdemo.other.Resource
import com.example.unittestdemo.data.local.ShoppingItem
import com.example.unittestdemo.data.remote.ImageResponse

interface ShoppingRepository {

    suspend fun insertItem(item: ShoppingItem)

    suspend fun deleteItem(item: ShoppingItem)

    fun getAllObservableItems(): List<ShoppingItem>

    fun getTotalPriceObservable(): LiveData<Float>

    suspend fun searchForImage(query: String): Resource<ImageResponse>

}