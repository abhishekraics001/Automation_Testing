package com.example.unittestdemo.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch

class SampleViewModel(private val dispatcher: CoroutineDispatcher) : ViewModel(){
    private var userData: Any? = null
    fun getUserData(): Any? = userData

    suspend fun saveSessionData() {
        viewModelScope.launch(dispatcher) {
            userData = "some_user_data"
        }
    }

    fun squareLong(l: Long): Long {
        return l * l
    }
}