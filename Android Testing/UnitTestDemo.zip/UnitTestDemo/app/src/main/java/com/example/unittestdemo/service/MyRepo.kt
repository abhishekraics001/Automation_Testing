package com.example.unittestdemo.service

import com.example.unittestdemo.service.ApiService

abstract class MyRepo : ApiService {
    override fun getApiUsers(): List<String> {
        return listOf("Balu","Balli")
    }
}